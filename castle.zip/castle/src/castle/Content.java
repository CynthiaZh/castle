package castle;

public class Content {
	public static final String HELP_TIPS1 = "迷路了吗？你可以做的命令有：go bye help";
	public static final String HELP_TIPS2 = "如：\tgo east";
	public static final String ERROR_TIPS1 = "那里没有门！";
	public static final String ERROR_TIPS2 = "指令错误！如果需要帮助，请输入 'help' 。";
	public static final String[][] DIRECTION = { 
			{ "east", "东方" }, { "west", "西方" }, { "south", "南方" },
			{ "north", "北方" }, { "up", "上方" }, { "down", "下方" },

	};

}

package castle;

public class Handler {

	public void doCmd(String word){};

	public boolean isBye() {
		return false;
	}
}
